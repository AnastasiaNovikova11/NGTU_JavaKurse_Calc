import java.util.ArrayList;
import java.util.Random;

public class SecondTask {

    void lentMatrix() {
        int[][] matrix = new int[6][6];
        Random random = new Random();
        ArrayList<Integer> elemOfLargeB = new ArrayList<>();
        ArrayList<Integer> elemSmallerB = new ArrayList<>();
        int q = 2;
        int p = 1;
        int b = random.nextInt(10);
        System.out.println("B=" + b);
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (i < j && (j - i) <= q) {
                    matrix[i][j] = random.nextInt(10);
                } else if (i > j && (i - j) <= p) {
                    matrix[i][j] = random.nextInt(10);
                } else if (i == j) {
                    matrix[i][j] = random.nextInt(10);
                } else {
                    matrix[i][j] = 0;
                }
            }
        }
        System.out.println("Исходная матрица:");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }
        int k = 0; //счетчик размера списка состоящего из элементов больших B
        int m = 0;//счетчик размера списка состоящего из элементов меньших B
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                if (matrix[i][j] != 0 && matrix[i][j] > b) {
                    k += 1;
                    elemOfLargeB.add(matrix[i][j]);
                } else if (matrix[i][j] != 0 && matrix[i][j] < b) {
                    m += 1;
                    elemSmallerB.add(matrix[i][j]);
                }
            }
        }
        int n = 0;
        int indI = 0;
        int indJ = 0;
        while (k > 0) {
            for (int i = 0; i < 6; i++) {
                for (int j = 0; j < 6; j++) {
                    if (matrix[i][j] != 0) {
                        if (n < elemOfLargeB.size()) {
                            matrix[i][j] = elemOfLargeB.get(n);
                            n += 1;
                            indJ = j;
                            indI = i;
                        }
                    }
                    k -= 1;

                }

            }
        }
        int t = 0;
        while (m > 0) {
            for (int i = indI; i < 6; i++) {
                for (int j = indJ; j < 6; j++) {
                    if (t >= elemSmallerB.size()) {
                        t = 0;
                    }
                    if (matrix[i][j] != 0) {
                        matrix[i][j] = elemSmallerB.get(t);
                        t += 1;
                    }
                    m -= 1;
                }
            }
        }


        System.out.println("Новая матрица:");
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println();
        }


    }
}
