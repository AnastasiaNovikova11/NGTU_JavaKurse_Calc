import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        FirstTask firstTask = new FirstTask();
        SecondTask secondTask = new SecondTask();
        while (true) {
            printMenu();
            int command = scanner.nextInt();
            if (command == 1) {
                firstTask.randomArray();
            } else if (command == 2) {
                System.out.println("Введите число линий для треугольника Паскаля");
                int lines = scanner.nextInt();
                secondTask.makeTriangularArray(lines);
            } else if (command == 0) {
                break;
            } else {
                System.out.println("Такой команды нет");
            }
        }
    }


    public static void printMenu() {
        System.out.println();
        System.out.println("Какое задание хотите проверить?");
        System.out.println("1-первое задание(заполнение и сортировка массива)");
        System.out.println("2-второе задание(треугольник Паскаля)");
        System.out.println("0-выход");
    }
}