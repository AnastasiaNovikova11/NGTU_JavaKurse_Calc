import java.util.Random;

public class FirstTask {
    void matrixMirroring() {
        Random rand = new Random();
        int[][] b = new int[4][4];
        int k = 0;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                while (k * 3 <= 16) {
                    int n = rand.nextInt(4);
                    int m = rand.nextInt(4);
                    b[n][m] = rand.nextInt(100);
                    k += 1;
                }


            }
        }
        System.out.println("Исходная матрица:");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                System.out.printf("%3d ", b[i][j]);
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("Отзеркаленная матрица:");
        for (int i = 0; i < b.length; i++) {
            for (int j = 0; j < b.length - i; j++) {
                int tmp = b[i][j];
                b[i][j] = b[b.length - 1 - j][b.length - 1 - i];
                b[b.length - 1 - j][b.length - 1 - i] = tmp;
            }
        }

        for (int i = 0; i < b.length; i++) {
            for (int j = 0; j < b.length; j++) {
                System.out.printf("%3d ", b[i][j]);
            }
            System.out.println();
        }

    }

}
