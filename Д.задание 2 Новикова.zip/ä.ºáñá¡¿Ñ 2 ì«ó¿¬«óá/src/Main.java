public class Main {
    public static void main(String[] args) {
        FirstTask firstTask = new FirstTask();
        System.out.println("Первое задание:");
        firstTask.matrixMirroring();
        System.out.println();

        System.out.println("Второе задание:");
        SecondTask secondTask = new SecondTask();
        secondTask.lentMatrix();
    }
}